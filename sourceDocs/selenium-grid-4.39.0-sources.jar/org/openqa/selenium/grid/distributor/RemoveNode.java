// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.grid.distributor;

import org.openqa.selenium.grid.data.NodeId;
import org.openqa.selenium.internal.Require;
import org.openqa.selenium.remote.http.HttpHandler;
import org.openqa.selenium.remote.http.HttpRequest;
import org.openqa.selenium.remote.http.HttpResponse;

class RemoveNode implements HttpHandler {

  private final Distributor distributor;
  private final NodeId nodeId;

  RemoveNode(Distributor distributor, NodeId nodeId) {
    this.distributor = Require.nonNull("Distributor", distributor);
    this.nodeId = Require.nonNull("Node id", nodeId);
  }

  @Override
  public HttpResponse execute(HttpRequest req) {
    distributor.remove(nodeId);
    return new HttpResponse();
  }
}
